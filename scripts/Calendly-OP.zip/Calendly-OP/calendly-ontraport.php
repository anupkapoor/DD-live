<?php

require_once('./src/Ontraport.php');

use OntraportAPI\Ontraport;
use OntraportAPI\ObjectType;

$payload = '{"event":"invitee.created","time":"2019-07-16T03:27:43Z","payload":{"event_type":{"uuid":"AAFGHUA2WXGMJ3YW","kind":"One-on-One","slug":"strategysession","name":"Strategy Session","duration":45,"owner":{"type":"users","uuid":"HDCCAFJM7SKAE54G"}},"event":{"uuid":"BED37J5Z4VCFLTRO","assigned_to":["Dedicated Developers"],"extended_assigned_to":[{"name":"Dedicated developers","email":"vishal@dedicateddevelopers.com","primary":true}],"start_time":"2019-07-22T10:00:00-04:00","start_time_pretty":"10:00am - Monday, July 22, 2019","invitee_start_time":"2019-07-22T22:00:00+08:00","invitee_start_time_pretty":"10:00pm - Monday, July 22, 2019","end_time":"2019-07-22T10:45:00-04:00","end_time_pretty":"10:45am - Monday, July 22, 2019","invitee_end_time":"2019-07-22T22:45:00+08:00","invitee_end_time_pretty":"10:45pm - Monday, July 22, 2019","created_at":"2019-07-15T23:27:42-04:00","location":"Skype","canceled":false,"canceler_name":null,"cancel_reason":null,"canceled_at":null},"invitee":{"uuid":"GHKHBZBETI3GBYME","first_name":"Samson","last_name":"Adonor","name":"Samson adonor","email":"test+3@gmail.com","text_reminder_number":null,"timezone":"Asia\/Shanghai","created_at":"2019-07-15T23:27:42-04:00","is_reschedule":false,"payments":[],"canceled":false,"canceler_name":null,"cancel_reason":null,"canceled_at":null},"questions_and_answers":[{"question":"Skype ID (Outside the US)","answer":" Access Code: 473860# Skype: dedicateddevelopers"},{"question":"Please indicate the type of project you would like to discuss.  Choose all that apply...","answer":"iPhone App\nAndroid App"},{"question":"Please describe your project in detail...","answer":"I am building a social networking application. i would like to work with you it help it get off the ground so i am ready to have a meeting with you."}],"questions_and_responses":{"2_question":"Skype ID (Outside the US)","2_response":" Access Code: 473860# Skype: dedicateddevelopers","3_question":"Please indicate the type of project you would like to discuss.  Choose all that apply...","3_response":"iPhone App\nAndroid App","4_question":"Please describe your project in detail...","4_response":"I am building a social networking application. i would like to work with you it help it get off the ground so i am ready to have a meeting with you."},"tracking":{"utm_campaign":null,"utm_source":null,"utm_medium":null,"utm_content":null,"utm_term":null,"salesforce_uuid":null},"old_event":null,"old_invitee":null,"new_event":null,"new_invitee":null}}';

$error[] = array();
//    $request_body = file_get_contents('php://input');
$request_body = $payload;           //ASSIGNING PAYLOAD 
    if(isset($request_body)){
        $data = json_decode(stripslashes($request_body),true);
        
    if (isset($data['payload']['invitee']['email']) && $data['payload']['invitee']['email'] != '' && $data['payload']['event_type']['name'] != "Discussion with Dedicated Developers") {
        //CHECKING WHETHER PAYLOAD IS EMPTY OR NOT
        $client = new Ontraport("2_21081_i2IJ6uMoT", "3beSoC1g7HJO8jG"); //initialize object
        
        //SEPERATING PAYLOAD DATA
        $email = $data['payload']['invitee']['email'];
        $status=($data['payload']['invitee']['canceled'])?" Cancelled Reason:". $data['payload']['invitee']['cancel_reason']:' Scheduled ';
        $note =  $data['payload']['invitee']['first_name'] .' '. $status .' For Event: '.$data['payload']['event_type']['name'].' On '.$data['payload']['event']['start_time_pretty']; 

        
            $com = '[{ "field":{"field":"email"}, "op":"=", "value":{"value":"' . $email . '"} }]';     //CHECKING EMAIL IN ONTRAPORT
            $requestParams = array(
                "objectID" => ObjectType::CONTACT,
                "condition" => $com
            );
            $response = $client->object()->retrieveMultiple($requestParams);        // GETTING PARTICULAR EMAIL DATA FROM ONTRAPORT
               
            $result = json_decode($response, TRUE);
            $contact = $result['data'];     //ASSIGNING EMAIL DATA FROM ONTRAPORT TO VARIABLE
                     
                if (isset($contact[0]['id']) && $contact[0]['id'] != "") { //contact found
                    
//                    $notes = ($data['payload']['questions_and_responses']['4_response']!='')?$obj->updateOAPNotes($data['payload']['questions_and_responses']['4_response']):'';
//                
                    
            $date_timestamp = explode('T',$data['payload']['event']['start_time']);
            $date = strtotime($data['payload']['event']['start_time']);
            $demo_date = $date;
            $time = explode('-',$date_timestamp[1]);
            $demo_time = $time[0]; 
            $current_status = ($data['payload']['invitee']['canceled']==true)?'canceled':'scheduled';      
                    //CREATING ARRAY TO PUT INTO ONTRAPORT
                   $requestParams = array(
                    'objectID' => ObjectType::CONTACT,
                    "id" => $contact[0]['id'],
                    'firstname' => $data['payload']['invitee']['first_name'],
                    'lastname' => $data['payload']['invitee']['last_name'],
                    '27161f1843' => $demo_date,
                    '27161f1844' => $demo_time,
                    'f1860' => $current_status,
                    'f1857' => $data['payload']['event_type']['name'],
                    'f1490' => 216,
                    'notes' => 'testing notes'   
                    );
                    if(isset($data['payload']['questions_and_responses']['1_response']) && $data['payload']['questions_and_responses']['1_response'] != ''){
                        $requestParams['f1384'] = $data['payload']['questions_and_responses']['1_response'];
                    }
                    if(isset($data['payload']['questions_and_responses']['2_response']) && $data['payload']['questions_and_responses']['2_response'] != ''){
                        $requestParams['office_phone'] = $data['payload']['questions_and_responses']['2_response'];
                    }
                    if(isset($data['payload']['questions_and_responses']['3_response']) && $data['payload']['questions_and_responses']['3_response'] != ''){
                        $requestParams['company'] = $data['payload']['questions_and_responses']['3_response'];
                    }
                    
                    $response = $client->object()->update($requestParams);      
                    $result = json_decode($response, TRUE);
                    $updated_data = $result['data'];
                    if (isset($updated_data['attrs']['id']) && $updated_data['attrs']['id']) {
                        
                        echo('updated');        // CONTACT UPDATED IN ONTRAPORT
                    $requestParams = array(         // CRATEING ARRAY FOR NOTES UPDATION
                        "objectID"  => 12, // Object type ID: 0
                        "contact_id"=>4011,
                        "object_type_id"=>0,
                        "data"=>"testing"
                        );
                    $response = $client->object()->update($requestParams);      //NOTES UPDATED IN ONTRAPORT
                    print_r($response);        
                    }
                    
                } else { //contact not found
                
                    $date_timestamp = explode('T',$data['payload']['event']['start_time']);
                    $date = strtotime($data['payload']['event']['start_time']);
                    $demo_date = $date;
                    $time = explode('-',$date_timestamp[1]);
                    $demo_time = $time[0]; 
                    $current_status = ($data['payload']['invitee']['canceled']==true)?'canceled':'scheduled';      
                    
                    $requestParams = array(     //ARRAY OF CONTACT DATA CREATED
                        'objectID' => ObjectType::CONTACT,
                        'email' => $data['payload']['invitee']['email'],
                        'firstname' => $data['payload']['invitee']['first_name'],
                        'lastname' => $data['payload']['invitee']['last_name'],
                        '27161f1843' => $demo_date,
                        '27161f1844' => $demo_time,
                        'f1860' => $current_status,
                        'f1857' => $data['payload']['event_type']['name'],
                        'f1490' => 216                
                        );
                        if(isset($data['payload']['questions_and_responses']['1_response']) && $data['payload']['questions_and_responses']['1_response'] != ''){
                            $requestParams['f1384'] = $data['payload']['questions_and_responses']['1_response'];
                        }
                        if(isset($data['payload']['questions_and_responses']['2_response']) && $data['payload']['questions_and_responses']['2_response'] != ''){
                            $requestParams['office_phone'] = $data['payload']['questions_and_responses']['2_response'];
                        }
                        if(isset($data['payload']['questions_and_responses']['3_response']) && $data['payload']['questions_and_responses']['3_response'] != ''){
                            $requestParams['company'] = $data['payload']['questions_and_responses']['3_response'];
                        }
                        $response = $client->contact()->create($requestParams);  //CONTACT CREATED IN ONTRAPORT
                        $result2 = json_decode($response, TRUE);
                        $created_data = $result2['data'];

                     if (isset($created_data['id']) && $created_data['id'] != "") {
                                        
                         $requestParams = array(        // ARRAY OF TAGS CREATED
                            "objectID" => ObjectType::CONTACT, // Object type ID: 0
                            "ids"      => $created_data['id'],
                            "add_list" => 99
                        );
                        $response = $client->object()->addTag($requestParams);      //TAGS ADDED TO CONTACT (IN ONTRAPORT)
                     }
                    
                }
    }
    }
                $file = @fopen("dedicate_developer.log", 'a+');
                @fwrite($file, date("Y-m-d:H:i:s") . "\t" . "Requested data:" . $request_body . "\t Error:". json_encode($error) ."\n");
                @fclose($file);
?>