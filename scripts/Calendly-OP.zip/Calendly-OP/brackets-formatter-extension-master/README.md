brackets-formatter-extension
============================

This extension adds auto-formatting function to Adobe Brackets.

If you install this extension, you can format `XML/HTML`, `CSS`, and `JavaScript` files by "Edit > Format" menu or "Ctrl+Shift+F" key.

Install
===

Please download zip and extract into arbitrary directory (or clone source files), then move the folder to the extensions folder (you can open this folder by clicking "Help > Show Extensions Folder" menu).

License
===
This software is licensed under MIT license.